# Dompetku - Personal Finance Tracker

## Overview

Dompetku is a personal finance tracking application that helps users manage their income and expenses. The application provides a dashboard interface for viewing financial summaries, recording transactions, and visualizing spending patterns through charts and trends. The name "Dompetku" means "My Wallet" in Indonesian, and the interface is localized for Indonesian users.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript, using Vite as the build tool and development server.

**UI Component Library**: shadcn/ui components built on top of Radix UI primitives, providing a comprehensive set of accessible, customizable components.

**Styling**: 
- Tailwind CSS for utility-first styling
- Custom design system based on Material Design 3 principles
- Theme support (light/dark mode) with CSS variables
- Design inspiration drawn from Stripe Dashboard, Wise App, and Notion for clean data presentation and friendly UX

**State Management**:
- TanStack Query (React Query) for server state management and data fetching
- React Hook Form for form state and validation
- Local React state for UI-specific concerns (theme, modals, filters)

**Routing**: Wouter for lightweight client-side routing.

**Charts & Visualization**: Recharts library for rendering pie charts (category breakdown) and area charts (monthly trends).

**Form Validation**: Zod schemas for runtime type validation, integrated with React Hook Form via @hookform/resolvers.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Design**: RESTful API endpoints under `/api` prefix:
- `GET /api/transactions` - Retrieve all transactions
- `POST /api/transactions` - Create new transaction
- `DELETE /api/transactions/:id` - Delete transaction
- `GET /api/summary` - Get financial summary statistics
- `GET /api/categories/summary` - Get category-wise breakdown
- `GET /api/trends` - Get monthly trend data

**Data Storage Strategy**: 
- Interface-based storage abstraction (`IStorage`) allowing for multiple implementations
- Currently using in-memory storage (`MemStorage`) with sample seed data
- Designed to support database persistence (Drizzle ORM configuration present for PostgreSQL/Neon)
- Transaction data includes type (income/expense), amount, category, description, and date

**Session Management**: Not currently implemented, but infrastructure includes session store dependencies (connect-pg-simple) suggesting future authentication plans.

**Build Process**: 
- Custom build script using esbuild for server bundling
- Vite for client bundling
- Production build creates a single deployable artifact

### Data Model

**Transaction Schema**:
- `id`: Unique identifier (string)
- `type`: Enum of "income" or "expense"
- `amount`: Positive number
- `category`: String (mapped to predefined categories)
- `description`: String
- `date`: ISO date string

**Categories**: Predefined categories with associated icons from Lucide React:
- Income: salary, freelance, investment, gift, other
- Expense: food, transport, shopping, bills, entertainment, health, education, other

**Computed Data**:
- Financial summaries (total balance, income, expenses with percentage changes)
- Category summaries for pie chart visualization
- Monthly trends for area chart visualization

### Development Workflow

**Development Mode**: 
- Vite dev server with HMR (Hot Module Replacement)
- Express middleware mode for API integration
- Source maps for debugging
- Replit-specific plugins for development banner and cartographer

**Type Safety**:
- Shared types between client and server via `@shared` alias
- Zod schemas used for runtime validation and TypeScript type inference
- Drizzle-Zod integration for database schema validation

**Code Organization**:
- `client/`: React frontend application
- `server/`: Express backend application  
- `shared/`: Shared schemas and types
- Path aliases configured: `@/` for client source, `@shared/` for shared code

## External Dependencies

### Primary Libraries

**UI & Styling**:
- Radix UI (@radix-ui/*) - Headless UI component primitives
- Tailwind CSS - Utility-first CSS framework
- class-variance-authority - Variant-based component styling
- Lucide React - Icon library

**Data Fetching & Forms**:
- @tanstack/react-query - Server state management
- react-hook-form - Form state and validation
- zod - Schema validation

**Charts & Visualization**:
- recharts - Chart components
- date-fns - Date manipulation and formatting

**Database & ORM** (configured but not actively used):
- drizzle-orm - TypeScript ORM
- @neondatabase/serverless - Neon PostgreSQL driver
- drizzle-zod - Zod schema generation from Drizzle

**Routing & Navigation**:
- wouter - Lightweight routing library

**Build Tools**:
- Vite - Frontend build tool and dev server
- esbuild - Fast JavaScript bundler for production
- tsx - TypeScript execution for development

### Infrastructure

**Session Storage** (dependencies present for future use):
- express-session
- connect-pg-simple
- memorystore

**Development Tools**:
- Replit-specific plugins for enhanced development experience
- TypeScript for type safety across the stack

### Font Resources

Google Fonts integration:
- Inter - Primary font for data and UI
- DM Sans, Architects Daughter, Fira Code, Geist Mono - Additional font options