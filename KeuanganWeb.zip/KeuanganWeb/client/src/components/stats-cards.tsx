import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight } from "lucide-react";
import type { FinancialSummary } from "@shared/schema";

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

function formatPercentage(value: number): string {
  const sign = value >= 0 ? "+" : "";
  return `${sign}${value.toFixed(1)}%`;
}

type StatsCardsProps = {
  summary: FinancialSummary | undefined;
  isLoading: boolean;
};

export function StatsCards({ summary, isLoading }: StatsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-8 w-8 rounded-md" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-32 mb-2" />
              <Skeleton className="h-4 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats = [
    {
      title: "Total Saldo",
      value: formatCurrency(summary?.totalBalance ?? 0),
      icon: Wallet,
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
      change: null,
      testId: "stat-balance",
    },
    {
      title: "Pemasukan Bulan Ini",
      value: formatCurrency(summary?.totalIncome ?? 0),
      icon: TrendingUp,
      iconBg: "bg-emerald-500/10 dark:bg-emerald-500/20",
      iconColor: "text-emerald-600 dark:text-emerald-400",
      change: summary?.incomeChange ?? 0,
      isPositive: true,
      testId: "stat-income",
    },
    {
      title: "Pengeluaran Bulan Ini",
      value: formatCurrency(summary?.totalExpense ?? 0),
      icon: TrendingDown,
      iconBg: "bg-rose-500/10 dark:bg-rose-500/20",
      iconColor: "text-rose-600 dark:text-rose-400",
      change: summary?.expenseChange ?? 0,
      isPositive: false,
      testId: "stat-expense",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
      {stats.map((stat) => (
        <Card key={stat.title} className="hover-elevate transition-all duration-200">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-md ${stat.iconBg}`}>
              <stat.icon className={`h-5 w-5 ${stat.iconColor}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div
              className="text-2xl md:text-3xl font-bold tabular-nums tracking-tight"
              data-testid={stat.testId}
            >
              {stat.value}
            </div>
            {stat.change !== null && (
              <div className="flex items-center gap-1 mt-1">
                {stat.change >= 0 ? (
                  <ArrowUpRight className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 text-rose-600 dark:text-rose-400" />
                )}
                <span
                  className={`text-sm font-medium ${
                    stat.change >= 0
                      ? "text-emerald-600 dark:text-emerald-400"
                      : "text-rose-600 dark:text-rose-400"
                  }`}
                >
                  {formatPercentage(stat.change)}
                </span>
                <span className="text-sm text-muted-foreground">vs bulan lalu</span>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
