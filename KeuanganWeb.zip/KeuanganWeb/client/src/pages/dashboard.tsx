import { useQuery, useMutation } from "@tanstack/react-query";
import { Wallet } from "lucide-react";
import { StatsCards } from "@/components/stats-cards";
import { TransactionForm } from "@/components/transaction-form";
import { TransactionList } from "@/components/transaction-list";
import { CategoryChart, TrendChart } from "@/components/charts";
import { ThemeToggle } from "@/components/theme-toggle";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type {
  Transaction,
  InsertTransaction,
  FinancialSummary,
  CategorySummary,
  MonthlyTrend,
} from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: summary, isLoading: isLoadingSummary } = useQuery<FinancialSummary>({
    queryKey: ["/api/summary"],
  });

  const { data: categoryData, isLoading: isLoadingCategories } = useQuery<CategorySummary[]>({
    queryKey: ["/api/categories/summary"],
  });

  const { data: trendData, isLoading: isLoadingTrend } = useQuery<MonthlyTrend[]>({
    queryKey: ["/api/trends"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trends"] });
      toast({
        title: "Berhasil!",
        description: "Transaksi berhasil ditambahkan",
      });
    },
    onError: () => {
      toast({
        title: "Gagal",
        description: "Terjadi kesalahan saat menyimpan transaksi",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/categories/summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trends"] });
      toast({
        title: "Berhasil!",
        description: "Transaksi berhasil dihapus",
      });
    },
    onError: () => {
      toast({
        title: "Gagal",
        description: "Terjadi kesalahan saat menghapus transaksi",
        variant: "destructive",
      });
    },
  });

  const handleCreateTransaction = async (data: InsertTransaction) => {
    await createMutation.mutateAsync(data);
  };

  const handleDeleteTransaction = (id: string) => {
    deleteMutation.mutate(id);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Wallet className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Dompetku</h1>
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Pelacak Keuangan Pribadi
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <TransactionForm
                onSubmit={handleCreateTransaction}
                isPending={createMutation.isPending}
              />
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <div className="space-y-6 sm:space-y-8">
          <section>
            <StatsCards summary={summary} isLoading={isLoadingSummary} />
          </section>

          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <TransactionList
                transactions={transactions}
                isLoading={isLoadingTransactions}
                onDelete={handleDeleteTransaction}
                isDeleting={deleteMutation.isPending}
              />
            </div>
            <div className="space-y-6">
              <CategoryChart data={categoryData} isLoading={isLoadingCategories} />
              <TrendChart data={trendData} isLoading={isLoadingTrend} />
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-sm text-muted-foreground">
            Dompetku - Kelola keuangan Anda dengan bijak
          </p>
        </div>
      </footer>
    </div>
  );
}
