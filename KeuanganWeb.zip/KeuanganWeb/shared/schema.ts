import { pgTable, text, varchar, integer, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Transaction types
export const transactionTypes = ["income", "expense"] as const;
export type TransactionType = (typeof transactionTypes)[number];

// Default categories with icons
export const DEFAULT_CATEGORIES = {
  income: [
    { id: "salary", label: "Gaji", icon: "Briefcase" },
    { id: "freelance", label: "Freelance", icon: "Laptop" },
    { id: "investment", label: "Investasi", icon: "TrendingUp" },
    { id: "gift", label: "Hadiah", icon: "Gift" },
    { id: "other_income", label: "Lainnya", icon: "Plus" },
  ],
  expense: [
    { id: "food", label: "Makanan", icon: "Utensils" },
    { id: "transport", label: "Transportasi", icon: "Car" },
    { id: "shopping", label: "Belanja", icon: "ShoppingBag" },
    { id: "bills", label: "Tagihan", icon: "Receipt" },
    { id: "entertainment", label: "Hiburan", icon: "Gamepad2" },
    { id: "health", label: "Kesehatan", icon: "Heart" },
    { id: "education", label: "Pendidikan", icon: "GraduationCap" },
    { id: "other_expense", label: "Lainnya", icon: "MoreHorizontal" },
  ],
} as const;

export const ALL_DEFAULT_CATEGORIES = [...DEFAULT_CATEGORIES.income, ...DEFAULT_CATEGORIES.expense];

// Transactions table
export const transactions = pgTable("transactions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  type: varchar("type", { length: 10 }).notNull(),
  amount: integer("amount").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  description: text("description").notNull(),
  date: varchar("date", { length: 10 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Custom categories table
export const categories = pgTable("categories", {
  id: varchar("id", { length: 36 }).primaryKey(),
  type: varchar("type", { length: 10 }).notNull(),
  label: varchar("label", { length: 50 }).notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Budgets table
export const budgets = pgTable("budgets", {
  id: varchar("id", { length: 36 }).primaryKey(),
  category: varchar("category", { length: 50 }).notNull().unique(),
  amount: integer("amount").notNull(),
  month: varchar("month", { length: 7 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod schemas for validation
export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
}).extend({
  amount: z.coerce.number().positive("Jumlah harus lebih dari 0"),
  category: z.string().min(1, "Kategori harus dipilih"),
  description: z.string().min(1, "Keterangan harus diisi"),
  date: z.string().min(1, "Tanggal harus dipilih"),
  type: z.enum(transactionTypes),
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
  createdAt: true,
}).extend({
  type: z.enum(transactionTypes),
  label: z.string().min(1, "Nama kategori harus diisi"),
  icon: z.string().min(1, "Icon harus dipilih"),
});

export const insertBudgetSchema = createInsertSchema(budgets).omit({
  id: true,
  createdAt: true,
}).extend({
  amount: z.coerce.number().positive("Budget harus lebih dari 0"),
  category: z.string().min(1, "Kategori harus dipilih"),
  month: z.string().min(1, "Bulan harus dipilih"),
});

// Types
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Category = typeof categories.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;

export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

// Summary types
export type FinancialSummary = {
  totalBalance: number;
  totalIncome: number;
  totalExpense: number;
  incomeChange: number;
  expenseChange: number;
};

export type CategorySummary = {
  category: string;
  label: string;
  amount: number;
  percentage: number;
  budget?: number;
  budgetPercentage?: number;
};

export type MonthlyTrend = {
  month: string;
  income: number;
  expense: number;
};

export type BudgetStatus = {
  category: string;
  label: string;
  budgetAmount: number;
  spentAmount: number;
  remainingAmount: number;
  percentage: number;
  isWarning: boolean;
  isExceeded: boolean;
};
