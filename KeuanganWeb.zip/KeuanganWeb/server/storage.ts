import { db } from "./db";
import { eq, desc, and, gte, lte, sql, like } from "drizzle-orm";
import { randomUUID } from "crypto";
import {
  transactions,
  categories,
  budgets,
  type Transaction,
  type InsertTransaction,
  type Category,
  type InsertCategory,
  type Budget,
  type InsertBudget,
  type FinancialSummary,
  type CategorySummary,
  type MonthlyTrend,
  type BudgetStatus,
  ALL_DEFAULT_CATEGORIES,
} from "@shared/schema";

export interface IStorage {
  // Transaction methods
  getTransactions(options?: {
    sortBy?: "date" | "amount";
    sortOrder?: "asc" | "desc";
    startDate?: string;
    endDate?: string;
    category?: string;
    search?: string;
  }): Promise<Transaction[]>;
  getTransaction(id: string): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  deleteTransaction(id: string): Promise<boolean>;

  // Category methods
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Budget methods
  getBudgets(month?: string): Promise<Budget[]>;
  getBudget(id: string): Promise<Budget | undefined>;
  createOrUpdateBudget(budget: InsertBudget): Promise<Budget>;
  deleteBudget(id: string): Promise<boolean>;
  getBudgetStatus(month: string): Promise<BudgetStatus[]>;

  // Summary methods
  getFinancialSummary(): Promise<FinancialSummary>;
  getCategorySummary(): Promise<CategorySummary[]>;
  getMonthlyTrend(): Promise<MonthlyTrend[]>;
}

export class DatabaseStorage implements IStorage {
  async getTransactions(options?: {
    sortBy?: "date" | "amount";
    sortOrder?: "asc" | "desc";
    startDate?: string;
    endDate?: string;
    category?: string;
    search?: string;
  }): Promise<Transaction[]> {
    const conditions = [];

    if (options?.startDate) {
      conditions.push(gte(transactions.date, options.startDate));
    }
    if (options?.endDate) {
      conditions.push(lte(transactions.date, options.endDate));
    }
    if (options?.category) {
      conditions.push(eq(transactions.category, options.category));
    }
    if (options?.search) {
      conditions.push(like(transactions.description, `%${options.search}%`));
    }

    const result = await db
      .select()
      .from(transactions)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(
        options?.sortOrder === "asc"
          ? options?.sortBy === "amount"
            ? transactions.amount
            : transactions.date
          : options?.sortBy === "amount"
            ? desc(transactions.amount)
            : desc(transactions.date)
      );

    return result;
  }

  async getTransaction(id: string): Promise<Transaction | undefined> {
    const result = await db
      .select()
      .from(transactions)
      .where(eq(transactions.id, id))
      .limit(1);
    return result[0];
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const newTransaction = { ...transaction, id };
    await db.insert(transactions).values(newTransaction);
    return newTransaction as Transaction;
  }

  async deleteTransaction(id: string): Promise<boolean> {
    const result = await db.delete(transactions).where(eq(transactions.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).orderBy(categories.label);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const newCategory = { ...category, id };
    await db.insert(categories).values(newCategory);
    return newCategory as Category;
  }

  async updateCategory(id: string, categoryUpdate: Partial<InsertCategory>): Promise<Category | undefined> {
    const result = await db
      .update(categories)
      .set(categoryUpdate)
      .where(eq(categories.id, id))
      .returning();
    return result[0];
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getBudgets(month?: string): Promise<Budget[]> {
    if (month) {
      return db.select().from(budgets).where(eq(budgets.month, month));
    }
    return db.select().from(budgets);
  }

  async getBudget(id: string): Promise<Budget | undefined> {
    const result = await db
      .select()
      .from(budgets)
      .where(eq(budgets.id, id))
      .limit(1);
    return result[0];
  }

  async createOrUpdateBudget(budget: InsertBudget): Promise<Budget> {
    const existing = await db
      .select()
      .from(budgets)
      .where(and(eq(budgets.category, budget.category), eq(budgets.month, budget.month)))
      .limit(1);

    if (existing[0]) {
      const result = await db
        .update(budgets)
        .set({ amount: budget.amount })
        .where(eq(budgets.id, existing[0].id))
        .returning();
      return result[0];
    }

    const id = randomUUID();
    const newBudget = { ...budget, id };
    await db.insert(budgets).values(newBudget);
    return newBudget as Budget;
  }

  async deleteBudget(id: string): Promise<boolean> {
    const result = await db.delete(budgets).where(eq(budgets.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getBudgetStatus(month: string): Promise<BudgetStatus[]> {
    const monthBudgets = await this.getBudgets(month);
    const customCategories = await this.getCategories();
    const allCategories = [
      ...ALL_DEFAULT_CATEGORIES,
      ...customCategories.map((c) => ({ id: c.id, label: c.label, icon: c.icon })),
    ];

    const startDate = `${month}-01`;
    const endDate = `${month}-31`;

    const monthTransactions = await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.type, "expense"),
          gte(transactions.date, startDate),
          lte(transactions.date, endDate)
        )
      );

    const categorySpending = new Map<string, number>();
    monthTransactions.forEach((t) => {
      const current = categorySpending.get(t.category) || 0;
      categorySpending.set(t.category, current + t.amount);
    });

    return monthBudgets.map((budget) => {
      const categoryInfo = allCategories.find((c) => c.id === budget.category);
      const spentAmount = categorySpending.get(budget.category) || 0;
      const percentage = (spentAmount / budget.amount) * 100;

      return {
        category: budget.category,
        label: categoryInfo?.label || budget.category,
        budgetAmount: budget.amount,
        spentAmount,
        remainingAmount: budget.amount - spentAmount,
        percentage,
        isWarning: percentage >= 80 && percentage < 100,
        isExceeded: percentage >= 100,
      };
    });
  }

  async getFinancialSummary(): Promise<FinancialSummary> {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;

    const currentMonthStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}`;
    const lastMonthStr = `${lastMonthYear}-${String(lastMonth + 1).padStart(2, "0")}`;

    const allTransactions = await db.select().from(transactions);

    const currentMonthTransactions = allTransactions.filter((t) =>
      t.date.startsWith(currentMonthStr)
    );
    const lastMonthTransactions = allTransactions.filter((t) =>
      t.date.startsWith(lastMonthStr)
    );

    const totalIncome = currentMonthTransactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpense = currentMonthTransactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    const lastMonthIncome = lastMonthTransactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);

    const lastMonthExpense = lastMonthTransactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    const allIncome = allTransactions
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + t.amount, 0);

    const allExpense = allTransactions
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + t.amount, 0);

    const totalBalance = allIncome - allExpense;

    const incomeChange =
      lastMonthIncome > 0
        ? ((totalIncome - lastMonthIncome) / lastMonthIncome) * 100
        : totalIncome > 0
          ? 100
          : 0;

    const expenseChange =
      lastMonthExpense > 0
        ? ((totalExpense - lastMonthExpense) / lastMonthExpense) * 100
        : totalExpense > 0
          ? 100
          : 0;

    return {
      totalBalance,
      totalIncome,
      totalExpense,
      incomeChange,
      expenseChange,
    };
  }

  async getCategorySummary(): Promise<CategorySummary[]> {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const currentMonthStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}`;

    const monthTransactions = await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.type, "expense"),
          like(transactions.date, `${currentMonthStr}%`)
        )
      );

    const customCategories = await this.getCategories();
    const allCategories = [
      ...ALL_DEFAULT_CATEGORIES,
      ...customCategories.map((c) => ({ id: c.id, label: c.label, icon: c.icon })),
    ];

    const monthBudgets = await this.getBudgets(currentMonthStr);
    const budgetMap = new Map(monthBudgets.map((b) => [b.category, b.amount]));

    const categoryTotals = new Map<string, number>();
    monthTransactions.forEach((t) => {
      const current = categoryTotals.get(t.category) || 0;
      categoryTotals.set(t.category, current + t.amount);
    });

    const totalExpense = monthTransactions.reduce((sum, t) => sum + t.amount, 0);

    const summary: CategorySummary[] = Array.from(categoryTotals.entries()).map(
      ([category, amount]) => {
        const categoryInfo = allCategories.find((c) => c.id === category);
        const budget = budgetMap.get(category);
        return {
          category,
          label: categoryInfo?.label || category,
          amount,
          percentage: totalExpense > 0 ? (amount / totalExpense) * 100 : 0,
          budget,
          budgetPercentage: budget ? (amount / budget) * 100 : undefined,
        };
      }
    );

    return summary.sort((a, b) => b.amount - a.amount);
  }

  async getMonthlyTrend(): Promise<MonthlyTrend[]> {
    const allTransactions = await db.select().from(transactions);
    const now = new Date();
    const trends: MonthlyTrend[] = [];

    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
      "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
    ];

    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;

      const monthTransactions = allTransactions.filter((t) =>
        t.date.startsWith(monthStr)
      );

      const income = monthTransactions
        .filter((t) => t.type === "income")
        .reduce((sum, t) => sum + t.amount, 0);

      const expense = monthTransactions
        .filter((t) => t.type === "expense")
        .reduce((sum, t) => sum + t.amount, 0);

      trends.push({
        month: monthNames[date.getMonth()],
        income,
        expense,
      });
    }

    return trends;
  }
}

export const storage = new DatabaseStorage();
