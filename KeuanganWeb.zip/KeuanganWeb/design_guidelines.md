# Design Guidelines: Personal Finance Tracker

## Design Approach

**Selected Approach:** Hybrid (Design System + Reference-Based)
- **Primary System:** Material Design 3 principles for data-rich interfaces
- **Reference Inspiration:** Stripe Dashboard (clean data presentation) + Wise App (friendly financial UX) + Notion (content organization)
- **Rationale:** Finance apps require clarity and trust while maintaining modern appeal. Material Design provides robust patterns for data visualization and forms, while fintech references ensure contemporary aesthetics.

## Core Design Elements

### Typography
- **Primary Font:** Inter (Google Fonts) - exceptional readability for numbers and data
- **Hierarchy:**
  - Hero/Page Titles: text-4xl font-bold (36px)
  - Section Headers: text-2xl font-semibold (24px)
  - Card Titles: text-lg font-semibold (18px)
  - Body Text: text-base (16px)
  - Data Labels: text-sm font-medium (14px)
  - Financial Numbers: text-2xl to text-4xl font-bold with tabular-nums

### Layout System
**Spacing Primitives:** Tailwind units 2, 4, 6, 8, 12, 16
- Component padding: p-6 (cards), p-4 (smaller elements)
- Section spacing: gap-6 for grids, gap-4 for lists
- Margins: mb-8 between major sections, mb-4 between related elements
- Container: max-w-7xl mx-auto px-6

### Component Library

**Dashboard Layout:**
- Top navigation bar with logo, page title, and user profile icon
- 3-column stats grid (desktop) → single column (mobile):
  - Total Balance card (prominent, larger)
  - Total Income card (this month)
  - Total Expenses card (this month)
- Each stat card: large number display, label, trend indicator (↑/↓ percentage vs last month)
- 2-column layout below: Transactions list (left, 60%) + Visualization charts (right, 40%)

**Transaction Entry Form:**
- Floating card/modal design with subtle shadow
- Fields: Amount (large numeric input), Category (dropdown with icons), Description, Date picker, Type toggle (Income/Expense)
- Submit button: full-width, prominent

**Transaction List:**
- Clean table/list with alternating subtle row backgrounds
- Each row: Category icon, Description, Date (text-sm), Amount (bold, right-aligned)
- Filter bar above list: Category dropdown, Date range picker, Search input
- Scrollable with max height, sticky header

**Visualization Charts:**
- Pie chart card: Expenses by Category (use Chart.js or similar)
- Line chart card: Monthly Trend (last 6 months)
- Charts in rounded cards with titles and legends

**Navigation:**
- Persistent top bar: Logo left, "Dashboard" center/left, "+ Add Transaction" button right
- Mobile: Hamburger menu for navigation

**Forms & Inputs:**
- Rounded borders (rounded-lg)
- Clear labels above inputs
- Focus states with border emphasis
- Icon prefixes for category selectors

### Images
**No hero image needed** - This is a utility-focused dashboard application. The interface should focus on data clarity and immediate functionality rather than marketing imagery.

### Animations
**Minimal, purposeful only:**
- Smooth transitions on card hovers (hover:shadow-lg transition-shadow)
- Chart animations on load (built into Chart.js)
- Modal/form slide-in entrance
- No scroll-triggered animations

### Accessibility
- All form inputs with proper labels and ARIA attributes
- Sufficient contrast ratios for financial data readability
- Focus indicators on all interactive elements
- Keyboard navigation for all functionality
- Tab order follows logical flow through forms and data

### Key Design Principles
1. **Data Clarity First:** Numbers and financial information must be immediately scannable
2. **Trust Through Professionalism:** Clean, organized layouts inspire confidence
3. **Efficient Workflows:** Common actions (add transaction) prominently accessible
4. **Visual Hierarchy:** Important totals larger than supporting details
5. **Responsive Density:** Desktop shows more data, mobile focuses on essentials